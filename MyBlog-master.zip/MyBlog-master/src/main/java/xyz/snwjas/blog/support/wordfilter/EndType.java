package xyz.snwjas.blog.support.wordfilter;

/**
 * 结束类型定义
 *
 * @author minghu.zhang
 **/
public enum EndType {

    /**
     * 有下一个，结束
     */
    HAS_NEXT, IS_END
}
