package xyz.snwjas.blog.support.wordfilter;

/**
 * 词汇类型
 *
 * @author minghu.zhang
 **/
public enum WordType {

	/**
	 * 黑名单/白名单
	 */
	BLACK, WHITE
}
