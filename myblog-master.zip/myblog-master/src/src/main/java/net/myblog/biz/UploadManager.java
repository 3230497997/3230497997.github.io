package net.myblog.biz;

import java.util.Scanner;

public class UploadManager {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner("");
		//修改测试
	}

}
